#pragma once;

enum Type {Cold = 1, Hot = 2, Dessert = 3};

class Dish
{
	char Name[20];
	int Price;
	Type Bl;
public:	
	Dish(char* Name = "no name", int Price = 00, Type Bl = Cold);	
	void Show();
	void ChangeName();
	void ChangePrice();
	void ChangeType();
	Dish& operator+(int a);
	Dish& operator-(int a);
	operator long();
};
