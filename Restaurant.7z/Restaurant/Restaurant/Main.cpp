#include <iostream>
#include "Dish.h"
using namespace std;

int main()
{
	setlocale(LC_ALL, "Russian");

	Dish a("���", 10);
	a.Show();
	cout << endl;
	a - 5;
	a.Show();
	cout << endl;
	long b = (long)a;
	cout << b << endl;	
	a + 10;
	a.Show();

	return 0;
}